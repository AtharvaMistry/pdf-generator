import React from 'react';
import pdfMake from 'pdfmake/build/pdfmake';//for generating PDF
import pdfFonts from 'pdfmake/build/vfs_fonts';//for font style in pdf
import './App.css';
// import RobotoRegular from './Roboto-Regular.ttf';


// pdfFonts.addFont(RobotoRegular);



pdfMake.vfs = pdfFonts.pdfMake.vfs;

function App(){
	function handleFormSubmit(event){
        event.preventDefault();
		const {name, profession, mobile, email,address, linkedIn,profile, skills, companyName,years,role,university,field,yearOfEDucation,result} = event.target;

		const documentMaking = {
			content: [
				// { text:`Name: ${name.value}`},
				// { text:`Profession:${profession.value}`},
				{ text:`RESUME`},
				{
					columns: [
					  { text: 'Name:', width: 'auto' },
					  { text: name.value, width: 'auto', margin: [10, 0, 0, 20] }, // Add left margin
					//   { text: 'Profession:', width: 'auto', margin: [20, 0, 0, 0] }, // Add left margin
					  { text: profession.value, width: 'auto',margin: [40, 0, 0, 20]  },
					],
				  },
				{ text: `Contact details:`, width: 'auto' ,margin: [0, 10, 0,5]},
				{ text:`Mobile:${mobile.value}`, width: 'auto' },
				{ text:`Email:${email.value}`, width: 'auto' },
				{ text:`Address:${address.value}`, width: 'auto' },
				{ text:`LinkedIn:${linkedIn.value}`, width: 'auto'},
			
			
				{ text:`Profile:${profile.value}`,margin: [0, 10, 0,5]},
				{ text:`Skills:${skills.value}`,margin: [0, 10, 0,5]},

				{ text:`Experience:`, width: 'auto' ,margin: [0, 10, 0,5]},
				{ text:`CompanyName:${companyName.value}`},
				{ text:`Years:${years.value}`},
				{ text:`Role:${role.value}`, width: 'auto'},

				{ text:`Education:`, width: 'auto' ,margin: [0, 10, 0,5]},
				{ text:`University:${university.value}`},
				{ text:`Field of Experience:${field.value}`},
				{ text:`Year of Education:${yearOfEDucation.value}`},
				{ text:`Result:${result.value}`, width: 'auto'}
			],
			// styles: {
			// 	// label:{
					
			// 	// },
			// 	contactDetails:{
			// 		fontSize: 14, // Increase the font size
			// 		bold: true,
			// 	}
			// }
		}
		const PDFgenerator = pdfMake.createPdf(documentMaking);
		PDFgenerator.open();
	}

  
    return (
      <div>
			<form className='container' onSubmit={handleFormSubmit}>
				<h1>Resume Generator</h1><br/><br/>

				<div className='div1'>
					<label className='label'>Name:</label>
					<input type="text" name='name' />
				</div><br/>

				<div className='div1'>
					<label className='label'>Profession:</label>
					<input type="text" name='profession'/>
				</div><br/>

			<div className='div1'>
				<label className='label'>Contact details:</label>
				<div>
					<input type="text" placeholder='mobile-number' name='mobile'/><br/><br/>
					<input type="text" placeholder='email' name='email'/><br/><br/>
					<input type="text" placeholder='address' name='address'/><br/><br/>
					<input type="text" placeholder='linkedIn' name='linkedIn'/><br/><br/>
				</div>
			</div><br/>


				<div className='div1'>
					<label className='label'>Profile:</label>
					<input type="text" name='profile'/>
				</div><br/>

				<div className='div1'>
					<label className='label'>Skills:</label>
					<input type="text" name='skills'/>
				</div><br/>

				<div className='div1'>
					<label className='label'>Experience:</label>
					<div>
						<input type="text" placeholder='company-name' name='companyName'/><br/><br/>
						<input type="text" placeholder='number-of-year' name='years'/><br/><br/>
						<input type="text" placeholder='role' name='role'/><br/><br/><br/>
					</div>
				</div><br/>

				<div className='div1'>
					<label className='label'>Education:</label>
					<div>
						<input type="text" placeholder='university' name='university'/><br/><br/>
						<input type="text" placeholder='field' name='field'/><br/><br/>
						<input type="text" placeholder='year' name='yearOfEDucation'/><br/><br/>
						<input type="text" placeholder='result' name='result'/><br/><br/>
					</div>
				</div><br/>

				<div className='button1'> 
					<button type="submit">Generate PDF</button><br/>
				</div>

			</form>
      </div>
    );
  
}

export default App;
